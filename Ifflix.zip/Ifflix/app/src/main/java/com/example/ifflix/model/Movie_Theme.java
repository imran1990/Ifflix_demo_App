package com.example.ifflix.model;

public class Movie_Theme {

    String movie_description;

    public Movie_Theme(String movie_description) {
        this.movie_description = movie_description;
    }

    public String getMovie_description() {
        return movie_description;
    }

    public void setMovie_description(String movie_description) {
        this.movie_description = movie_description;
    }
}
