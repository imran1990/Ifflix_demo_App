package com.example.ifflix.model;

public class Movie_Subtitle {

    String subtitle;

    public Movie_Subtitle(String subtitle) {
        this.subtitle = subtitle;
    }

    public String getSubtitle() {
        return subtitle;
    }

    public void setSubtitle(String subtitle) {
        this.subtitle = subtitle;
    }
}
