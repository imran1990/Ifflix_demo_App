package com.example.ifflix.model;

public class Category {

    String movie_category;
    int color;

    public Category(String movie_category, int color) {
        this.movie_category = movie_category;
        this.color = color;
    }

    public String getMovie_category() {
        return movie_category;
    }

    public void setMovie_category(String movie_category) {
        this.movie_category = movie_category;
    }

    public int getColor() {
        return color;
    }

    public void setColor(int color) {
        this.color = color;
    }
}
