package com.example.ifflix.model;

import java.util.ArrayList;

public class Application_Ifflix {


    String moviename;
    int movieimage;



    public Application_Ifflix(String moviename, int movieimage) {
        this.moviename = moviename;
        this.movieimage = movieimage;
    }

    public String getMoviename() {
        return moviename;
    }

    public int getMovieimage() {
        return movieimage;
    }

    public void setMoviename(String moviename) {
        this.moviename = moviename;
    }

    public void setMovieimage(int movieimage) {
        this.movieimage = movieimage;
    }
}
