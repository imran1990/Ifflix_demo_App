package com.example.ifflix.adapter;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.ifflix.Main2Activity;
import com.example.ifflix.R;
import com.example.ifflix.model.Application_Ifflix;
import com.example.ifflix.model.Footer;

import java.util.ArrayList;
import java.util.zip.Inflater;

public class FooterCustomAdapter extends RecyclerView.Adapter<FooterCustomAdapter.Holder> {

    ArrayList<Footer> dataset3 = new ArrayList<>();
    Context context;
    LayoutInflater inflater;

    public FooterCustomAdapter(ArrayList<Footer> dataset, Context context) {
        this.dataset3 = dataset;
        this.context = context;
        this.inflater = LayoutInflater.from(context);
    }

    @NonNull
    @Override
    public Holder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = inflater.inflate(R.layout.footer_layout,viewGroup,false);
        Holder holder = new Holder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull Holder holder, int i) {

        Footer footer = dataset3.get(i);
        holder.iconimage.setImageResource(footer.getFootericon());
        holder.iconname.setText(footer.getIconname());
        holder.layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, Main2Activity.class);
                context.startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return dataset3.size();
    }

    class Holder extends RecyclerView.ViewHolder {

        RelativeLayout layout;
        ImageView iconimage;
        TextView  iconname;

        public Holder(@NonNull View itemView) {
            super(itemView);

            layout     = itemView.findViewById(R.id.footerlayout);
            iconimage = itemView.findViewById(R.id.footerimg);
            iconname = itemView.findViewById(R.id.footertext);

        }
    }
}
