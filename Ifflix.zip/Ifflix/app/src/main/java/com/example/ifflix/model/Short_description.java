package com.example.ifflix.model;

public class Short_description {

    int releasing_year;
    String movie_type;
    int movie_duration;
    Season season;
    String series;

    public Short_description(int releasing_year, String movie_type, int movie_duration, Season season, String series) {
        this.releasing_year = releasing_year;
        this.movie_type = movie_type;
        this.movie_duration = movie_duration;
        this.season = season;
        this.series = series;
    }

    public int getReleasing_year() {
        return releasing_year;
    }

    public void setReleasing_year(int releasing_year) {
        this.releasing_year = releasing_year;
    }

    public String getMovie_type() {
        return movie_type;
    }

    public void setMovie_type(String movie_type) {
        this.movie_type = movie_type;
    }

    public int getMovie_duration() {
        return movie_duration;
    }

    public void setMovie_duration(int movie_duration) {
        this.movie_duration = movie_duration;
    }

    public Season getSeason() {
        return season;
    }

    public void setSeason(Season season) {
        this.season = season;
    }

    public String getSeries() {
        return series;
    }

    public void setSeries(String series) {
        this.series = series;
    }
}
