package com.example.ifflix;

import android.app.Application;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.example.ifflix.adapter.CategoryCustomAdapter;
import com.example.ifflix.adapter.CustomAdapter;
import com.example.ifflix.adapter.CustomAdapter1;
import com.example.ifflix.adapter.CustomAdapter2;
import com.example.ifflix.adapter.FooterCustomAdapter;
import com.example.ifflix.model.Application_Ifflix;
import com.example.ifflix.model.Category;
import com.example.ifflix.model.Footer;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {


    ArrayList<Application_Ifflix> dataset = new ArrayList<>();
    ArrayList<Application_Ifflix> dataset1 = new ArrayList<>();
    ArrayList<Application_Ifflix> dataset2 = new ArrayList<>();
    ArrayList<Category> dataset0 = new ArrayList<>();
    ArrayList<Footer> dataset3 = new ArrayList<>();

    RecyclerView recyclerView0;
    RecyclerView recyclerView;
    RecyclerView recyclerView2;
    RecyclerView recyclerView3;
    RecyclerView footerRecyclerView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        categorySampleData();
        createSampleData() ;
        createSampleData1();
        createSampleData2();
        footerSampledata();

        initRecyclerView();

    }



    void initRecyclerView(){

        RecyclerView recyclerView0 = findViewById(R.id.recyclerView0);
        recyclerView =findViewById(R.id.recyclerView1);
        recyclerView2 =findViewById(R.id.recyclerView2);
        recyclerView3 =findViewById(R.id.recyclerView3);
        footerRecyclerView =findViewById(R.id.footerRecyclerView);

        recyclerView0.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL,false));
        recyclerView.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL,false));
        recyclerView2.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL,false));
        recyclerView3.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL,false));
        footerRecyclerView.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL,false));



     CategoryCustomAdapter adapter0 = new CategoryCustomAdapter(dataset0,this);
        CustomAdapter adapter = new CustomAdapter(dataset,this);
        CustomAdapter1 adapter1 = new CustomAdapter1(dataset1,this);
        CustomAdapter2 adapter2 = new CustomAdapter2(dataset2,this);
        FooterCustomAdapter adapter3 = new FooterCustomAdapter(dataset3,this);



        recyclerView0.setAdapter(adapter0);
        recyclerView.setAdapter(adapter);
        recyclerView2.setAdapter(adapter1);
        recyclerView3.setAdapter(adapter2);
        footerRecyclerView.setAdapter(adapter3);


    }



    void categorySampleData(){

        Category category1 = new Category("HINDI",R.color.redcolor);
        dataset0.add(category1);

        Category category2 = new Category("ACTION",R.color.blackcolor);
        dataset0.add(category2);

        Category category3 = new Category("HORROR",R.color.blackcolor);
        dataset0.add(category3);

        Category category4 = new Category("MUSIC",R.color.blackcolor);
        dataset0.add(category4);

        Category category5 = new Category("DRAMA",R.color.blackcolor);
        dataset0.add(category5);

        Category category6 = new Category("SCI",R.color.blackcolor);
        dataset0.add(category6);



    }

    void createSampleData(){

        Application_Ifflix movie1 = new Application_Ifflix("Aquaman",R.drawable.aquaman_poster);
        dataset.add(movie1);

        Application_Ifflix movie2 = new Application_Ifflix("Robin Hood",R.drawable.robinhood1);
        dataset.add(movie2);

        Application_Ifflix movie3 = new Application_Ifflix("47 Ronin",R.drawable.ronin47);
        dataset.add(movie3);

        Application_Ifflix movie4 = new Application_Ifflix("Venom",R.drawable.venom);
        dataset.add(movie4);


    }

    void createSampleData1(){

        Application_Ifflix movie1= new Application_Ifflix("Avengers",R.drawable.avengersinfinity);
        dataset1.add(movie1);

        Application_Ifflix movie2 =new Application_Ifflix("Black Panther",R.drawable.blackpanther);
        dataset1.add(movie2);

        Application_Ifflix movie3 = new Application_Ifflix("Mortal Engines",R.drawable.mortalengines);
        dataset1.add(movie3);

        Application_Ifflix movie4 =  new Application_Ifflix("Replicas",R.drawable.replicas);
        dataset1.add(movie4);

    }

    void createSampleData2(){

        Application_Ifflix movie1= new Application_Ifflix("KabiKhushi",R.drawable.kabikhushi);
        dataset2.add(movie1);

        Application_Ifflix movie2 =new Application_Ifflix("KuchKuch",R.drawable.kuchkuch);
        dataset2.add(movie2);

        Application_Ifflix movie3 = new Application_Ifflix("Krrish",R.drawable.krrish);
        dataset2.add(movie3);

        Application_Ifflix movie4 =  new Application_Ifflix("ThugHindustan",R.drawable.thughindustan);
        dataset2.add(movie4);

    }


    void footerSampledata(){

        Footer icon1= new Footer(R.drawable.ic_home,"Home");
        dataset3.add(icon1);

        Footer icon2= new Footer(R.drawable.ic_feed,"Feed");
        dataset3.add(icon2);

        Footer icon3= new Footer(R.drawable.ic_livetv,"live");
        dataset3.add(icon3);

        Footer icon4= new Footer(R.drawable.ic_kid,"Kid");
        dataset3.add(icon4);

        Footer icon5= new Footer(R.drawable.ic_download,"Download");
        dataset3.add(icon5);

    }



}
