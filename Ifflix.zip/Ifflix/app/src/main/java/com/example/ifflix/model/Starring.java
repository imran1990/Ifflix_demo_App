package com.example.ifflix.model;

import java.util.ArrayList;

public class Starring {

    String maleacter_name;
    String femaleacter_name;
    ArrayList<Staffname>staffname;

    public Starring(String maleacter_name, String femaleacter_name, ArrayList<Staffname> staffname) {
        this.maleacter_name = maleacter_name;
        this.femaleacter_name = femaleacter_name;
        this.staffname = staffname;
    }

    public String getMaleacter_name() {
        return maleacter_name;
    }

    public void setMaleacter_name(String maleacter_name) {
        this.maleacter_name = maleacter_name;
    }

    public String getFemaleacter_name() {
        return femaleacter_name;
    }

    public void setFemaleacter_name(String femaleacter_name) {
        this.femaleacter_name = femaleacter_name;
    }

    public ArrayList<Staffname> getStaffname() {
        return staffname;
    }

    public void setStaffname(ArrayList<Staffname> staffname) {
        this.staffname = staffname;
    }
}
