package com.example.ifflix.model;

import java.util.ArrayList;

public class Season {
    String season_name;
    ArrayList<Episodename>episode;

    public Season(String season_name, ArrayList<Episodename> episode) {
        this.season_name = season_name;
        this.episode = episode;
    }

    public String getSeason_name() {
        return season_name;
    }

    public void setSeason_name(String season_name) {
        this.season_name = season_name;
    }

    public ArrayList<Episodename> getEpisode() {
        return episode;
    }

    public void setEpisode(ArrayList<Episodename> episode) {
        this.episode = episode;
    }
}
