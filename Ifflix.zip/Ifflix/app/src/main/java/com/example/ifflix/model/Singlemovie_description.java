package com.example.ifflix.model;

import android.graphics.Bitmap;

import java.util.ArrayList;

public class Singlemovie_description {
    String movie_name;
    Starring starring;
    Directorname directorname;
    Short_description shortdeescription;
    Movie_Theme movietheme;
    ArrayList<Movie_Subtitle>moviesubtitle;
    Category category;
    Bitmap movie_image;

    public Singlemovie_description(String movie_name, Starring starring, Directorname directorname, Short_description shortdeescription, Movie_Theme movietheme, ArrayList<Movie_Subtitle> moviesubtitle, Category category, Bitmap movie_image) {
        this.movie_name = movie_name;
        this.starring = starring;
        this.directorname = directorname;
        this.shortdeescription = shortdeescription;
        this.movietheme = movietheme;
        this.moviesubtitle = moviesubtitle;
        this.category = category;
        this.movie_image = movie_image;
    }

    public String getMovie_name() {
        return movie_name;
    }

    public void setMovie_name(String movie_name) {
        this.movie_name = movie_name;
    }

    public Starring getStarring() {
        return starring;
    }

    public void setStarring(Starring starring) {
        this.starring = starring;
    }

    public Directorname getDirectorname() {
        return directorname;
    }

    public void setDirectorname(Directorname directorname) {
        this.directorname = directorname;
    }

    public Short_description getShortdeescription() {
        return shortdeescription;
    }

    public void setShortdeescription(Short_description shortdeescription) {
        this.shortdeescription = shortdeescription;
    }

    public Movie_Theme getMovietheme() {
        return movietheme;
    }

    public void setMovietheme(Movie_Theme movietheme) {
        this.movietheme = movietheme;
    }

    public ArrayList<Movie_Subtitle> getMoviesubtitle() {
        return moviesubtitle;
    }

    public void setMoviesubtitle(ArrayList<Movie_Subtitle> moviesubtitle) {
        this.moviesubtitle = moviesubtitle;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    public Bitmap getMovie_image() {
        return movie_image;
    }

    public void setMovie_image(Bitmap movie_image) {
        this.movie_image = movie_image;
    }
}
