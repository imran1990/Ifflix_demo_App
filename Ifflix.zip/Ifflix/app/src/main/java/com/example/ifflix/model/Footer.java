package com.example.ifflix.model;

public class Footer {

    int footericon;
    String iconname;

    public Footer(int footericon, String iconname) {
        this.footericon = footericon;
        this.iconname = iconname;
    }

    public int getFootericon() {
        return footericon;
    }

    public void setFootericon(int footericon) {
        this.footericon = footericon;
    }

    public String getIconname() {
        return iconname;
    }

    public void setIconname(String iconname) {
        this.iconname = iconname;
    }
}
