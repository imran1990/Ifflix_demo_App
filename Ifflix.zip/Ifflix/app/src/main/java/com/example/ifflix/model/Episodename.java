package com.example.ifflix.model;

public class Episodename {

    String episode_name;

    public Episodename(String episode_name) {
        this.episode_name = episode_name;
    }

    public String getEpisode_name() {
        return episode_name;
    }

    public void setEpisode_name(String episode_name) {
        this.episode_name = episode_name;
    }
}
