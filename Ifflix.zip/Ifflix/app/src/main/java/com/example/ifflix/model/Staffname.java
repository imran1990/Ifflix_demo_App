package com.example.ifflix.model;

public class Staffname {
    String cruememeber_name;


    public Staffname(String cruememeber_name) {
        this.cruememeber_name = cruememeber_name;
    }


    public String getCruememeber_name() {
        return cruememeber_name;
    }

    public void setCruememeber_name(String cruememeber_name) {
        this.cruememeber_name = cruememeber_name;
    }
}
