package com.example.ifflix.adapter;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.ifflix.Main2Activity;
import com.example.ifflix.R;
import com.example.ifflix.model.Application_Ifflix;

import java.util.ArrayList;
import java.util.zip.Inflater;

public class CustomAdapter2 extends RecyclerView.Adapter<CustomAdapter2.Holder> {

    ArrayList<Application_Ifflix> dataset2 = new ArrayList<>();
    Context context;
    LayoutInflater inflater;

    public CustomAdapter2(ArrayList<Application_Ifflix> dataset, Context context) {
        this.dataset2 = dataset;
        this.context = context;
        this.inflater = LayoutInflater.from(context);
    }

    @NonNull
    @Override
    public Holder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = inflater.inflate(R.layout.item_layout1,viewGroup,false);
        Holder holder = new Holder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull Holder holder, int i) {

        Application_Ifflix application_ifflix = dataset2.get(i);
        holder.movieimage.setImageResource(application_ifflix.getMovieimage());
        holder.moviename.setText(application_ifflix.getMoviename());
        holder.layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, Main2Activity.class);
                context.startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return dataset2.size();
    }

    class Holder extends RecyclerView.ViewHolder {

        RelativeLayout layout;
        ImageView movieimage;
        TextView  moviename;

        public Holder(@NonNull View itemView) {
            super(itemView);

            layout     = itemView.findViewById(R.id.layout);
            movieimage = itemView.findViewById(R.id.aquamanimage);
            moviename = itemView.findViewById(R.id.textviewlayout1);

        }
    }
}
