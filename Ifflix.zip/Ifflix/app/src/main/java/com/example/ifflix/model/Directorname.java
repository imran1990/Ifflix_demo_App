package com.example.ifflix.model;

public class Directorname {

    String director_name;

    public Directorname(String director_name) {
        this.director_name = director_name;
    }

    public String getDirector_name() {
        return director_name;
    }

    public void setDirector_name(String director_name) {
        this.director_name = director_name;
    }
}
